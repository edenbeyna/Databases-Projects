drop TABLE admissions CASCADE;
drop TABLE university CASCADE;
drop TABLE country CASCADE;
drop TABLE region;
drop TABLE incomegroup;




