insert into donors values('Alice', 'Krembo', 50);
insert into donors values('Alice1', 'Krembo', 50);
insert into donors values('Alice1', 'Variety', 50);
